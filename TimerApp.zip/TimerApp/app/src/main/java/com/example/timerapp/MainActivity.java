package com.example.timerapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import java.util.Locale;
public class MainActivity extends AppCompatActivity {
    private static final long START_TIME = 30000;


    private TextView mTextViewCountDown;
    private Button mButtonStartPause;
    private Button getButtonReset;

    private CountDownTimer mCountDownTimer;
    private boolean mTimerRunning;

    private long mTimeleftInMillis = START_TIME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextViewCountDown = findViewById(R.id.text_view_countdown);
        mButtonStartPause = findViewById(R.id.button_start_pause);
        getButtonReset = findViewById(R.id.buttonreset);

        mButtonStartPause.setOnClickListener(v -> {
            if (mTimerRunning){
                pauseTimer();
            } else {
                startTimer();
            }
        });
        getButtonReset.setOnClickListener(v -> resettimer());

        updateCountDownText();
    }

    private void startTimer(){
        mCountDownTimer = new CountDownTimer(mTimeleftInMillis,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeleftInMillis = millisUntilFinished;
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
                mButtonStartPause.setText("スタート");
                getButtonReset.setVisibility(View.INVISIBLE);
            }
        }.start();

        mTimerRunning = true;
        mButtonStartPause.setText("一時停止");
        getButtonReset.setVisibility(View.INVISIBLE);
    }
    private void pauseTimer(){
        mCountDownTimer.cancel();
        mTimerRunning = false;
        mButtonStartPause.setText("スタート");
        getButtonReset.setVisibility(View.VISIBLE);
    }
    private void resettimer(){
        mTimeleftInMillis = START_TIME;
        updateCountDownText();
        mButtonStartPause.setVisibility(View.VISIBLE);
        getButtonReset.setVisibility(View.INVISIBLE);
    }
    private void updateCountDownText(){
        int minutes = (int) (mTimeleftInMillis/1000)/60;
        int seconds = (int) (mTimeleftInMillis/1000)%60;
        String timerLeftFormatted = String.format(Locale.getDefault(),"%02d:%02d", minutes, seconds);
        mTextViewCountDown.setText((timerLeftFormatted));
    }
}